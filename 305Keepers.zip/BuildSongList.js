var SelectedArtist = document.getElementById('FolderListId');
var directory = encodeURI(SelectedArtist.value);
CreateSongList(directory);



